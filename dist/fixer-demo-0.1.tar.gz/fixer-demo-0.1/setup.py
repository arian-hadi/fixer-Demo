from setuptools import setup
setup(name = "fixer-demo",
      version = '0.1',
      description = 'getting rates with the help of fixer' ,
      url = '#',
      author = 'Arian Hadi',
      author_email = 'arianhadi2003@gmail.com',
      license = 'MIT',
      packages = ['fixer'],
      zip_safe = False)